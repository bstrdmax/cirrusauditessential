
export interface CodeFile {
  name: string;
  content: string;
}

export interface GroundingSource {
  title?: string;
  uri?: string;
}
